﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        // CONEXIÓN ENTITY FRAMEWORK
        pubsEntities db = new pubsEntities();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        // =========================
        // 🔵 SELECCIÓN (σ)
        // =========================

        private void btnAutoresCA_Click(object sender, EventArgs e)
        {
            dgvPubs.DataSource = db.authors
                .Where(a => a.state == "CA")
                .ToList();
        }

        private void btnLibrosPrecio_Click(object sender, EventArgs e)
        {
            dgvPubs.DataSource = db.titles
                .Where(t => t.price > 15)
                .ToList();
        }

        private void btnTiendasWA_Click(object sender, EventArgs e)
        {
            dgvPubs.DataSource = db.stores
                .Where(s => s.state == "WA")
                .ToList();
        }

        // =========================
        // 🟢 PROYECCIÓN (π)
        // =========================

        private void btnAliasAutores_Click(object sender, EventArgs e)
        {
            dgvPubs.DataSource = db.authors.Select(a => new
            {
                a.au_fname,
                a.au_lname
            }).ToList();
        }

        private void btnAliasLibros_Click(object sender, EventArgs e)
        {
            dgvPubs.DataSource = db.titles.Select(t => new
            {
                t.title,
                t.price
            }).ToList();
        }

        private void btnAliasTiendas_Click(object sender, EventArgs e)
        {
            dgvPubs.DataSource = db.stores.Select(s => new
            {
                s.stor_name,
                s.city
            }).ToList();
        }

        // =========================
        // 🟡 RENOMBRAMIENTO (ρ)
        // =========================

        private void btnRenAutorAlias_Click(object sender, EventArgs e)
        {
            dgvPubs.DataSource = db.authors.Select(a => new
            {
                NombreAutor = a.au_fname,
                ApellidoAutor = a.au_lname
            }).ToList();
        }

        private void btnRenLibroAlias_Click(object sender, EventArgs e)
        {
            dgvPubs.DataSource = db.titles.Select(t => new
            {
                TituloLibro = t.title,   // ✔ corregido
                PrecioLibro = t.price
            }).ToList();
        }

        private void btnRenTiendaAlias_Click(object sender, EventArgs e)
        {
            dgvPubs.DataSource = db.stores.Select(s => new
            {
                NombreTienda = s.stor_name,
                CiudadTienda = s.city
            }).ToList();
        }

        // =========================
        // 🔵 UNIÓN (∪)
        // =========================

        private void btnUnionCiudades_Click(object sender, EventArgs e)
        {
            dgvPubs.DataSource =
                db.authors.Select(a => a.city)
                .Union(db.stores.Select(s => s.city))
                .Select(x => new { Ciudad = x })
                .ToList();
        }

        private void btnUnionEstados_Click(object sender, EventArgs e)
        {
            dgvPubs.DataSource =
                db.authors.Select(a => a.state)
                .Union(db.stores.Select(s => s.state))
                .Select(x => new { Estado = x })
                .ToList();
        }

        private void btnUnionIDs_Click(object sender, EventArgs e)
        {
            dgvPubs.DataSource =
                db.sales.Select(s => s.title_id)
                .Union(db.titles.Select(t => t.title_id))
                .Select(x => new { ID = x })
                .ToList();
        }

        // =========================
        // 🔴 DIFERENCIA (−)
        // =========================

        private void btnEstadosSinTiendas_Click(object sender, EventArgs e)
        {
            dgvPubs.DataSource =
                db.authors.Select(a => a.state)
                .Except(db.stores.Select(s => s.state))
                .Select(x => new { Estado = x })
                .ToList();
        }

        private void btnLibrosNoVendidos_Click(object sender, EventArgs e)
        {
            var vendidos = db.sales.Select(s => s.title_id);

            dgvPubs.DataSource = db.titles
                .Where(t => !vendidos.Contains(t.title_id))
                .Select(t => new { t.title })   // ✔ corregido
                .ToList();
        }

        private void btnAutoresSinContrato_Click(object sender, EventArgs e)
        {
            dgvPubs.DataSource = db.authors
                .Where(a => a.contract == false)
                .ToList();
        }

        // =========================
        // 🟣 PRODUCTO CARTESIANO (×)
        // =========================

        private void btnAutoresTiendas_Click(object sender, EventArgs e)
        {
            dgvPubs.DataSource =
                (from a in db.authors
                 from s in db.stores
                 select new
                 {
                     Autor = a.au_lname,
                     Tienda = s.stor_name
                 }).ToList();
        }

        private void btnLibrosEditoriales_Click(object sender, EventArgs e)
        {
            dgvPubs.DataSource =
                (from t in db.titles
                 from p in db.publishers
                 select new
                 {
                     Libro = t.title,   // ✔ corregido
                     Editorial = p.pub_name
                 }).ToList();
        }

        private void btnTiendasEditoriales_Click(object sender, EventArgs e)
        {
            dgvPubs.DataSource =
                (from s in db.stores
                 from p in db.publishers
                 select new
                 {
                     Tienda = s.stor_name,
                     Editorial = p.pub_name
                 }).ToList();
        }

        // DataGridView (opcional)
        private void dgvPubs_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}