﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAutoresCA = new System.Windows.Forms.Button();
            this.btnLibrosPrecio = new System.Windows.Forms.Button();
            this.btnTiendasWA = new System.Windows.Forms.Button();
            this.btnAliasAutores = new System.Windows.Forms.Button();
            this.btnAliasLibros = new System.Windows.Forms.Button();
            this.btnAliasTiendas = new System.Windows.Forms.Button();
            this.dgvPubs = new System.Windows.Forms.DataGridView();
            this.btnUnionEstados = new System.Windows.Forms.Button();
            this.btnUnionIDs = new System.Windows.Forms.Button();
            this.btnUnionCiudades = new System.Windows.Forms.Button();
            this.btnLibrosEditoriales = new System.Windows.Forms.Button();
            this.btnTiendasEditoriales = new System.Windows.Forms.Button();
            this.btnAutoresTiendas = new System.Windows.Forms.Button();
            this.btnLibrosNoVendidos = new System.Windows.Forms.Button();
            this.btnAutoresSinContrato = new System.Windows.Forms.Button();
            this.btnEstadosSinTiendas = new System.Windows.Forms.Button();
            this.btnRenLibroAlias = new System.Windows.Forms.Button();
            this.btnRenTiendaAlias = new System.Windows.Forms.Button();
            this.btnRenAutorAlias = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPubs)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAutoresCA
            // 
            this.btnAutoresCA.Location = new System.Drawing.Point(40, 72);
            this.btnAutoresCA.Name = "btnAutoresCA";
            this.btnAutoresCA.Size = new System.Drawing.Size(97, 23);
            this.btnAutoresCA.TabIndex = 0;
            this.btnAutoresCA.Text = "Autores CA";
            this.btnAutoresCA.UseVisualStyleBackColor = true;
            this.btnAutoresCA.Click += new System.EventHandler(this.btnAutoresCA_Click);
            // 
            // btnLibrosPrecio
            // 
            this.btnLibrosPrecio.Location = new System.Drawing.Point(40, 101);
            this.btnLibrosPrecio.Name = "btnLibrosPrecio";
            this.btnLibrosPrecio.Size = new System.Drawing.Size(97, 23);
            this.btnLibrosPrecio.TabIndex = 1;
            this.btnLibrosPrecio.Text = "Libros Precio >15";
            this.btnLibrosPrecio.UseVisualStyleBackColor = true;
            this.btnLibrosPrecio.Click += new System.EventHandler(this.btnLibrosPrecio_Click);
            // 
            // btnTiendasWA
            // 
            this.btnTiendasWA.Location = new System.Drawing.Point(40, 130);
            this.btnTiendasWA.Name = "btnTiendasWA";
            this.btnTiendasWA.Size = new System.Drawing.Size(97, 23);
            this.btnTiendasWA.TabIndex = 3;
            this.btnTiendasWA.Text = "Tiendas WA";
            this.btnTiendasWA.UseVisualStyleBackColor = true;
            this.btnTiendasWA.Click += new System.EventHandler(this.btnTiendasWA_Click);
            // 
            // btnAliasAutores
            // 
            this.btnAliasAutores.Location = new System.Drawing.Point(163, 70);
            this.btnAliasAutores.Name = "btnAliasAutores";
            this.btnAliasAutores.Size = new System.Drawing.Size(95, 23);
            this.btnAliasAutores.TabIndex = 2;
            this.btnAliasAutores.Text = "Nombre Autores";
            this.btnAliasAutores.UseVisualStyleBackColor = true;
            this.btnAliasAutores.Click += new System.EventHandler(this.btnAliasAutores_Click);
            // 
            // btnAliasLibros
            // 
            this.btnAliasLibros.Location = new System.Drawing.Point(163, 101);
            this.btnAliasLibros.Name = "btnAliasLibros";
            this.btnAliasLibros.Size = new System.Drawing.Size(95, 23);
            this.btnAliasLibros.TabIndex = 7;
            this.btnAliasLibros.Text = "Título y Precio";
            this.btnAliasLibros.UseVisualStyleBackColor = true;
            this.btnAliasLibros.Click += new System.EventHandler(this.btnAliasLibros_Click);
            // 
            // btnAliasTiendas
            // 
            this.btnAliasTiendas.Location = new System.Drawing.Point(163, 130);
            this.btnAliasTiendas.Name = "btnAliasTiendas";
            this.btnAliasTiendas.Size = new System.Drawing.Size(95, 23);
            this.btnAliasTiendas.TabIndex = 6;
            this.btnAliasTiendas.Text = "Estados Únicos";
            this.btnAliasTiendas.UseVisualStyleBackColor = true;
            this.btnAliasTiendas.Click += new System.EventHandler(this.btnAliasTiendas_Click);
            // 
            // dgvPubs
            // 
            this.dgvPubs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPubs.Location = new System.Drawing.Point(12, 208);
            this.dgvPubs.Name = "dgvPubs";
            this.dgvPubs.Size = new System.Drawing.Size(1016, 358);
            this.dgvPubs.TabIndex = 21;
            this.dgvPubs.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPubs_CellContentClick);
            // 
            // btnUnionEstados
            // 
            this.btnUnionEstados.Location = new System.Drawing.Point(601, 101);
            this.btnUnionEstados.Name = "btnUnionEstados";
            this.btnUnionEstados.Size = new System.Drawing.Size(90, 23);
            this.btnUnionEstados.TabIndex = 24;
            this.btnUnionEstados.Text = "Unión Estados";
            this.btnUnionEstados.UseVisualStyleBackColor = true;
            this.btnUnionEstados.Click += new System.EventHandler(this.btnUnionEstados_Click);
            // 
            // btnUnionIDs
            // 
            this.btnUnionIDs.Location = new System.Drawing.Point(601, 130);
            this.btnUnionIDs.Name = "btnUnionIDs";
            this.btnUnionIDs.Size = new System.Drawing.Size(90, 23);
            this.btnUnionIDs.TabIndex = 23;
            this.btnUnionIDs.Text = "Unión IDs";
            this.btnUnionIDs.UseVisualStyleBackColor = true;
            this.btnUnionIDs.Click += new System.EventHandler(this.btnUnionIDs_Click);
            // 
            // btnUnionCiudades
            // 
            this.btnUnionCiudades.Location = new System.Drawing.Point(601, 72);
            this.btnUnionCiudades.Name = "btnUnionCiudades";
            this.btnUnionCiudades.Size = new System.Drawing.Size(90, 23);
            this.btnUnionCiudades.TabIndex = 22;
            this.btnUnionCiudades.Text = "Unión Ciudades";
            this.btnUnionCiudades.UseVisualStyleBackColor = true;
            this.btnUnionCiudades.Click += new System.EventHandler(this.btnUnionCiudades_Click);
            // 
            // btnLibrosEditoriales
            // 
            this.btnLibrosEditoriales.Location = new System.Drawing.Point(910, 101);
            this.btnLibrosEditoriales.Name = "btnLibrosEditoriales";
            this.btnLibrosEditoriales.Size = new System.Drawing.Size(118, 23);
            this.btnLibrosEditoriales.TabIndex = 30;
            this.btnLibrosEditoriales.Text = "Libros y Editoriales";
            this.btnLibrosEditoriales.UseVisualStyleBackColor = true;
            this.btnLibrosEditoriales.Click += new System.EventHandler(this.btnLibrosEditoriales_Click);
            // 
            // btnTiendasEditoriales
            // 
            this.btnTiendasEditoriales.Location = new System.Drawing.Point(910, 130);
            this.btnTiendasEditoriales.Name = "btnTiendasEditoriales";
            this.btnTiendasEditoriales.Size = new System.Drawing.Size(118, 23);
            this.btnTiendasEditoriales.TabIndex = 29;
            this.btnTiendasEditoriales.Text = "Tiendas y Editoriales";
            this.btnTiendasEditoriales.UseVisualStyleBackColor = true;
            this.btnTiendasEditoriales.Click += new System.EventHandler(this.btnTiendasEditoriales_Click);
            // 
            // btnAutoresTiendas
            // 
            this.btnAutoresTiendas.Location = new System.Drawing.Point(910, 72);
            this.btnAutoresTiendas.Name = "btnAutoresTiendas";
            this.btnAutoresTiendas.Size = new System.Drawing.Size(118, 23);
            this.btnAutoresTiendas.TabIndex = 28;
            this.btnAutoresTiendas.Text = "Autores y Tiendas";
            this.btnAutoresTiendas.UseVisualStyleBackColor = true;
            this.btnAutoresTiendas.Click += new System.EventHandler(this.btnAutoresTiendas_Click);
            // 
            // btnLibrosNoVendidos
            // 
            this.btnLibrosNoVendidos.Location = new System.Drawing.Point(741, 101);
            this.btnLibrosNoVendidos.Name = "btnLibrosNoVendidos";
            this.btnLibrosNoVendidos.Size = new System.Drawing.Size(122, 23);
            this.btnLibrosNoVendidos.TabIndex = 27;
            this.btnLibrosNoVendidos.Text = "Libros no Vendidos";
            this.btnLibrosNoVendidos.UseVisualStyleBackColor = true;
            this.btnLibrosNoVendidos.Click += new System.EventHandler(this.btnLibrosNoVendidos_Click);
            // 
            // btnAutoresSinContrato
            // 
            this.btnAutoresSinContrato.Location = new System.Drawing.Point(741, 130);
            this.btnAutoresSinContrato.Name = "btnAutoresSinContrato";
            this.btnAutoresSinContrato.Size = new System.Drawing.Size(122, 23);
            this.btnAutoresSinContrato.TabIndex = 26;
            this.btnAutoresSinContrato.Text = "Autores sin Contrato";
            this.btnAutoresSinContrato.UseVisualStyleBackColor = true;
            this.btnAutoresSinContrato.Click += new System.EventHandler(this.btnAutoresSinContrato_Click);
            // 
            // btnEstadosSinTiendas
            // 
            this.btnEstadosSinTiendas.Location = new System.Drawing.Point(741, 72);
            this.btnEstadosSinTiendas.Name = "btnEstadosSinTiendas";
            this.btnEstadosSinTiendas.Size = new System.Drawing.Size(122, 23);
            this.btnEstadosSinTiendas.TabIndex = 25;
            this.btnEstadosSinTiendas.Text = "Estados sin Tiendas";
            this.btnEstadosSinTiendas.UseVisualStyleBackColor = true;
            this.btnEstadosSinTiendas.Click += new System.EventHandler(this.btnEstadosSinTiendas_Click);
            // 
            // btnRenLibroAlias
            // 
            this.btnRenLibroAlias.Location = new System.Drawing.Point(296, 99);
            this.btnRenLibroAlias.Name = "btnRenLibroAlias";
            this.btnRenLibroAlias.Size = new System.Drawing.Size(108, 23);
            this.btnRenLibroAlias.TabIndex = 33;
            this.btnRenLibroAlias.Text = "Libros con Alias";
            this.btnRenLibroAlias.UseVisualStyleBackColor = true;
            this.btnRenLibroAlias.Click += new System.EventHandler(this.btnRenLibroAlias_Click);
            // 
            // btnRenTiendaAlias
            // 
            this.btnRenTiendaAlias.Location = new System.Drawing.Point(296, 128);
            this.btnRenTiendaAlias.Name = "btnRenTiendaAlias";
            this.btnRenTiendaAlias.Size = new System.Drawing.Size(108, 23);
            this.btnRenTiendaAlias.TabIndex = 32;
            this.btnRenTiendaAlias.Text = "Tiendas con Alias";
            this.btnRenTiendaAlias.UseVisualStyleBackColor = true;
            this.btnRenTiendaAlias.Click += new System.EventHandler(this.btnRenTiendaAlias_Click);
            // 
            // btnRenAutorAlias
            // 
            this.btnRenAutorAlias.Location = new System.Drawing.Point(296, 70);
            this.btnRenAutorAlias.Name = "btnRenAutorAlias";
            this.btnRenAutorAlias.Size = new System.Drawing.Size(108, 23);
            this.btnRenAutorAlias.TabIndex = 31;
            this.btnRenAutorAlias.Text = "Autores con Alias";
            this.btnRenAutorAlias.UseVisualStyleBackColor = true;
            this.btnRenAutorAlias.Click += new System.EventHandler(this.btnRenAutorAlias_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(60, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 34;
            this.label1.Text = "SELECCIÓN";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(171, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 13);
            this.label2.TabIndex = 35;
            this.label2.Text = "PROYECCIÓN";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(623, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 13);
            this.label3.TabIndex = 36;
            this.label3.Text = "UNIÓN";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(293, 54);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 13);
            this.label4.TabIndex = 37;
            this.label4.Text = "RENOMBRAMIENTO";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(898, 54);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(140, 13);
            this.label5.TabIndex = 38;
            this.label5.Text = "PRODUCTO CARTESIANO";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(767, 54);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 13);
            this.label6.TabIndex = 39;
            this.label6.Text = "DIFERENCIA";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(802, 22);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 13);
            this.label7.TabIndex = 40;
            this.label7.Text = "BINARIAS";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(181, 22);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 13);
            this.label8.TabIndex = 41;
            this.label8.Text = "UNARIAS";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1050, 614);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnRenLibroAlias);
            this.Controls.Add(this.btnRenTiendaAlias);
            this.Controls.Add(this.btnRenAutorAlias);
            this.Controls.Add(this.btnLibrosEditoriales);
            this.Controls.Add(this.btnTiendasEditoriales);
            this.Controls.Add(this.btnAutoresTiendas);
            this.Controls.Add(this.btnLibrosNoVendidos);
            this.Controls.Add(this.btnAutoresSinContrato);
            this.Controls.Add(this.btnEstadosSinTiendas);
            this.Controls.Add(this.btnUnionEstados);
            this.Controls.Add(this.btnUnionIDs);
            this.Controls.Add(this.btnUnionCiudades);
            this.Controls.Add(this.dgvPubs);
            this.Controls.Add(this.btnAliasLibros);
            this.Controls.Add(this.btnAliasTiendas);
            this.Controls.Add(this.btnTiendasWA);
            this.Controls.Add(this.btnAliasAutores);
            this.Controls.Add(this.btnLibrosPrecio);
            this.Controls.Add(this.btnAutoresCA);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPubs)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAutoresCA;
        private System.Windows.Forms.Button btnLibrosPrecio;
        private System.Windows.Forms.Button btnTiendasWA;
        private System.Windows.Forms.Button btnAliasAutores;
        private System.Windows.Forms.Button btnAliasLibros;
        private System.Windows.Forms.Button btnAliasTiendas;
        private System.Windows.Forms.DataGridView dgvPubs;
        private System.Windows.Forms.Button btnUnionEstados;
        private System.Windows.Forms.Button btnUnionIDs;
        private System.Windows.Forms.Button btnUnionCiudades;
        private System.Windows.Forms.Button btnLibrosEditoriales;
        private System.Windows.Forms.Button btnTiendasEditoriales;
        private System.Windows.Forms.Button btnAutoresTiendas;
        private System.Windows.Forms.Button btnLibrosNoVendidos;
        private System.Windows.Forms.Button btnAutoresSinContrato;
        private System.Windows.Forms.Button btnEstadosSinTiendas;
        private System.Windows.Forms.Button btnRenLibroAlias;
        private System.Windows.Forms.Button btnRenTiendaAlias;
        private System.Windows.Forms.Button btnRenAutorAlias;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
    }
}

