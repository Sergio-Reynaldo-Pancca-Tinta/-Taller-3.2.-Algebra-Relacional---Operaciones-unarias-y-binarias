﻿namespace taller_3._2_northwind
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.ProductsSel = new System.Windows.Forms.Button();
            this.CustomersSel = new System.Windows.Forms.Button();
            this.OrdersSel = new System.Windows.Forms.Button();
            this.dgvNorthwind = new System.Windows.Forms.DataGridView();
            this.CustomersSuppliersExcept = new System.Windows.Forms.Button();
            this.CustomersEmployeesExcept = new System.Windows.Forms.Button();
            this.RegionShippersCross = new System.Windows.Forms.Button();
            this.EmployeesCategoriesCross = new System.Windows.Forms.Button();
            this.SuppliersProj = new System.Windows.Forms.Button();
            this.CategoriesProj = new System.Windows.Forms.Button();
            this.CustomersRen = new System.Windows.Forms.Button();
            this.EmployeesCustomersUnion = new System.Windows.Forms.Button();
            this.CustomersSuppliersUnion = new System.Windows.Forms.Button();
            this.ProductsOrderDetailsExcept = new System.Windows.Forms.Button();
            this.TerritoriesShippersCross = new System.Windows.Forms.Button();
            this.EmployeesProj = new System.Windows.Forms.Button();
            this.ProductsRen = new System.Windows.Forms.Button();
            this.ShippersRen = new System.Windows.Forms.Button();
            this.SuppliersOrdersUnion = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNorthwind)).BeginInit();
            this.SuspendLayout();
            // 
            // ProductsSel
            // 
            this.ProductsSel.Location = new System.Drawing.Point(549, 47);
            this.ProductsSel.Name = "ProductsSel";
            this.ProductsSel.Size = new System.Drawing.Size(99, 27);
            this.ProductsSel.TabIndex = 0;
            this.ProductsSel.Text = "btnProductsSel";
            this.ProductsSel.UseVisualStyleBackColor = true;
            this.ProductsSel.Click += new System.EventHandler(this.button1_Click);
            // 
            // CustomersSel
            // 
            this.CustomersSel.Location = new System.Drawing.Point(554, 94);
            this.CustomersSel.Name = "CustomersSel";
            this.CustomersSel.Size = new System.Drawing.Size(99, 30);
            this.CustomersSel.TabIndex = 1;
            this.CustomersSel.Text = "btnCustomersSel";
            this.CustomersSel.UseVisualStyleBackColor = true;
            this.CustomersSel.Click += new System.EventHandler(this.CustomersSel_Click);
            // 
            // OrdersSel
            // 
            this.OrdersSel.Location = new System.Drawing.Point(554, 138);
            this.OrdersSel.Name = "OrdersSel";
            this.OrdersSel.Size = new System.Drawing.Size(99, 30);
            this.OrdersSel.TabIndex = 2;
            this.OrdersSel.Text = "btnOrdersSel";
            this.OrdersSel.UseVisualStyleBackColor = true;
            this.OrdersSel.Click += new System.EventHandler(this.OrdersSel_Click);
            // 
            // dgvNorthwind
            // 
            this.dgvNorthwind.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNorthwind.Location = new System.Drawing.Point(549, 216);
            this.dgvNorthwind.Name = "dgvNorthwind";
            this.dgvNorthwind.Size = new System.Drawing.Size(917, 443);
            this.dgvNorthwind.TabIndex = 3;
            // 
            // CustomersSuppliersExcept
            // 
            this.CustomersSuppliersExcept.Location = new System.Drawing.Point(1096, 42);
            this.CustomersSuppliersExcept.Name = "CustomersSuppliersExcept";
            this.CustomersSuppliersExcept.Size = new System.Drawing.Size(89, 39);
            this.CustomersSuppliersExcept.TabIndex = 4;
            this.CustomersSuppliersExcept.Text = "btnCustomersSuppliersExcept";
            this.CustomersSuppliersExcept.UseVisualStyleBackColor = true;
            this.CustomersSuppliersExcept.Click += new System.EventHandler(this.CustomersSuppliersExcept_Click);
            // 
            // CustomersEmployeesExcept
            // 
            this.CustomersEmployeesExcept.Location = new System.Drawing.Point(1096, 94);
            this.CustomersEmployeesExcept.Name = "CustomersEmployeesExcept";
            this.CustomersEmployeesExcept.Size = new System.Drawing.Size(89, 38);
            this.CustomersEmployeesExcept.TabIndex = 5;
            this.CustomersEmployeesExcept.Text = "btnCustomersEmployeesExcept";
            this.CustomersEmployeesExcept.UseVisualStyleBackColor = true;
            this.CustomersEmployeesExcept.Click += new System.EventHandler(this.CustomersEmployeesExcept_Click);
            // 
            // RegionShippersCross
            // 
            this.RegionShippersCross.Location = new System.Drawing.Point(1273, 42);
            this.RegionShippersCross.Name = "RegionShippersCross";
            this.RegionShippersCross.Size = new System.Drawing.Size(75, 23);
            this.RegionShippersCross.TabIndex = 6;
            this.RegionShippersCross.Text = "btnRegionShippersCross";
            this.RegionShippersCross.UseVisualStyleBackColor = true;
            this.RegionShippersCross.Click += new System.EventHandler(this.RegionShippersCross_Click);
            // 
            // EmployeesCategoriesCross
            // 
            this.EmployeesCategoriesCross.Location = new System.Drawing.Point(1273, 99);
            this.EmployeesCategoriesCross.Name = "EmployeesCategoriesCross";
            this.EmployeesCategoriesCross.Size = new System.Drawing.Size(75, 23);
            this.EmployeesCategoriesCross.TabIndex = 7;
            this.EmployeesCategoriesCross.Text = "btnEmployeesCategoriesCross";
            this.EmployeesCategoriesCross.UseVisualStyleBackColor = true;
            this.EmployeesCategoriesCross.Click += new System.EventHandler(this.EmployeesCategoriesCross_Click);
            // 
            // SuppliersProj
            // 
            this.SuppliersProj.Location = new System.Drawing.Point(687, 45);
            this.SuppliersProj.Name = "SuppliersProj";
            this.SuppliersProj.Size = new System.Drawing.Size(97, 29);
            this.SuppliersProj.TabIndex = 8;
            this.SuppliersProj.Text = "btnSuppliersProj";
            this.SuppliersProj.UseVisualStyleBackColor = true;
            this.SuppliersProj.Click += new System.EventHandler(this.SuppliersProj_Click);
            // 
            // CategoriesProj
            // 
            this.CategoriesProj.Location = new System.Drawing.Point(687, 138);
            this.CategoriesProj.Name = "CategoriesProj";
            this.CategoriesProj.Size = new System.Drawing.Size(97, 30);
            this.CategoriesProj.TabIndex = 9;
            this.CategoriesProj.Text = "btnCategoriesProj";
            this.CategoriesProj.UseVisualStyleBackColor = true;
            this.CategoriesProj.Click += new System.EventHandler(this.CategoriesProj_Click);
            // 
            // CustomersRen
            // 
            this.CustomersRen.Location = new System.Drawing.Point(819, 94);
            this.CustomersRen.Name = "CustomersRen";
            this.CustomersRen.Size = new System.Drawing.Size(94, 28);
            this.CustomersRen.TabIndex = 10;
            this.CustomersRen.Text = "btnCustomersRen";
            this.CustomersRen.UseVisualStyleBackColor = true;
            this.CustomersRen.Click += new System.EventHandler(this.CustomersRen_Click);
            // 
            // EmployeesCustomersUnion
            // 
            this.EmployeesCustomersUnion.Location = new System.Drawing.Point(952, 42);
            this.EmployeesCustomersUnion.Name = "EmployeesCustomersUnion";
            this.EmployeesCustomersUnion.Size = new System.Drawing.Size(107, 39);
            this.EmployeesCustomersUnion.TabIndex = 11;
            this.EmployeesCustomersUnion.Text = "btnEmployeesCustomersUnion";
            this.EmployeesCustomersUnion.UseVisualStyleBackColor = true;
            this.EmployeesCustomersUnion.Click += new System.EventHandler(this.EmployeesCustomersUnion_Click);
            // 
            // CustomersSuppliersUnion
            // 
            this.CustomersSuppliersUnion.Location = new System.Drawing.Point(952, 138);
            this.CustomersSuppliersUnion.Name = "CustomersSuppliersUnion";
            this.CustomersSuppliersUnion.Size = new System.Drawing.Size(107, 41);
            this.CustomersSuppliersUnion.TabIndex = 12;
            this.CustomersSuppliersUnion.Text = "btnCustomersSuppliersUnion";
            this.CustomersSuppliersUnion.UseVisualStyleBackColor = true;
            this.CustomersSuppliersUnion.Click += new System.EventHandler(this.CustomersSuppliersUnion_Click);
            // 
            // ProductsOrderDetailsExcept
            // 
            this.ProductsOrderDetailsExcept.Location = new System.Drawing.Point(1096, 138);
            this.ProductsOrderDetailsExcept.Name = "ProductsOrderDetailsExcept";
            this.ProductsOrderDetailsExcept.Size = new System.Drawing.Size(89, 41);
            this.ProductsOrderDetailsExcept.TabIndex = 13;
            this.ProductsOrderDetailsExcept.Text = "btnProductsOrderDetailsExcept";
            this.ProductsOrderDetailsExcept.UseVisualStyleBackColor = true;
            this.ProductsOrderDetailsExcept.Click += new System.EventHandler(this.ProductsOrderDetailsExcept_Click);
            // 
            // TerritoriesShippersCross
            // 
            this.TerritoriesShippersCross.Location = new System.Drawing.Point(1273, 156);
            this.TerritoriesShippersCross.Name = "TerritoriesShippersCross";
            this.TerritoriesShippersCross.Size = new System.Drawing.Size(75, 23);
            this.TerritoriesShippersCross.TabIndex = 14;
            this.TerritoriesShippersCross.Text = "btnTerritoriesShippersCross";
            this.TerritoriesShippersCross.UseVisualStyleBackColor = true;
            this.TerritoriesShippersCross.Click += new System.EventHandler(this.TerritoriesShippersCross_Click);
            // 
            // EmployeesProj
            // 
            this.EmployeesProj.Location = new System.Drawing.Point(687, 94);
            this.EmployeesProj.Name = "EmployeesProj";
            this.EmployeesProj.Size = new System.Drawing.Size(97, 28);
            this.EmployeesProj.TabIndex = 16;
            this.EmployeesProj.Text = "btnEmployeesProj";
            this.EmployeesProj.UseVisualStyleBackColor = true;
            this.EmployeesProj.Click += new System.EventHandler(this.EmployeesProj_Click);
            // 
            // ProductsRen
            // 
            this.ProductsRen.Location = new System.Drawing.Point(819, 47);
            this.ProductsRen.Name = "ProductsRen";
            this.ProductsRen.Size = new System.Drawing.Size(94, 27);
            this.ProductsRen.TabIndex = 17;
            this.ProductsRen.Text = "btnProductsRen";
            this.ProductsRen.UseVisualStyleBackColor = true;
            this.ProductsRen.Click += new System.EventHandler(this.ProductsRen_Click);
            // 
            // ShippersRen
            // 
            this.ShippersRen.Location = new System.Drawing.Point(819, 138);
            this.ShippersRen.Name = "ShippersRen";
            this.ShippersRen.Size = new System.Drawing.Size(94, 30);
            this.ShippersRen.TabIndex = 18;
            this.ShippersRen.Text = "btnShippersRen";
            this.ShippersRen.UseVisualStyleBackColor = true;
            this.ShippersRen.Click += new System.EventHandler(this.ShippersRen_Click);
            // 
            // SuppliersOrdersUnion
            // 
            this.SuppliersOrdersUnion.Location = new System.Drawing.Point(952, 91);
            this.SuppliersOrdersUnion.Name = "SuppliersOrdersUnion";
            this.SuppliersOrdersUnion.Size = new System.Drawing.Size(107, 41);
            this.SuppliersOrdersUnion.TabIndex = 19;
            this.SuppliersOrdersUnion.Text = "btnSuppliersOrdersUnion";
            this.SuppliersOrdersUnion.UseVisualStyleBackColor = true;
            this.SuppliersOrdersUnion.Click += new System.EventHandler(this.SuppliersOrdersUnion_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(562, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 20;
            this.label1.Text = "SELECCIÓN";

            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(695, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 13);
            this.label2.TabIndex = 21;
            this.label2.Text = "PROYECCIÓN";
 
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(807, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 13);
            this.label3.TabIndex = 22;
            this.label3.Text = "RENOMBRAMIENTO  ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(977, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 13);
            this.label4.TabIndex = 23;
            this.label4.Text = "UNIÓN";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(1107, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 13);
            this.label5.TabIndex = 24;
            this.label5.Text = "DIFERENCIA";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(1236, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(143, 13);
            this.label6.TabIndex = 25;
            this.label6.Text = "PRODUCTO CARTESIANO ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1497, 703);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SuppliersOrdersUnion);
            this.Controls.Add(this.ShippersRen);
            this.Controls.Add(this.ProductsRen);
            this.Controls.Add(this.EmployeesProj);
            this.Controls.Add(this.TerritoriesShippersCross);
            this.Controls.Add(this.ProductsOrderDetailsExcept);
            this.Controls.Add(this.CustomersSuppliersUnion);
            this.Controls.Add(this.EmployeesCustomersUnion);
            this.Controls.Add(this.CustomersRen);
            this.Controls.Add(this.CategoriesProj);
            this.Controls.Add(this.SuppliersProj);
            this.Controls.Add(this.EmployeesCategoriesCross);
            this.Controls.Add(this.RegionShippersCross);
            this.Controls.Add(this.CustomersEmployeesExcept);
            this.Controls.Add(this.CustomersSuppliersExcept);
            this.Controls.Add(this.dgvNorthwind);
            this.Controls.Add(this.OrdersSel);
            this.Controls.Add(this.CustomersSel);
            this.Controls.Add(this.ProductsSel);
            this.Name = "Form1";
            this.Text = "Form1";

            ((System.ComponentModel.ISupportInitialize)(this.dgvNorthwind)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ProductsSel;
        private System.Windows.Forms.Button CustomersSel;
        private System.Windows.Forms.Button OrdersSel;
        private System.Windows.Forms.DataGridView dgvNorthwind;
        private System.Windows.Forms.Button CustomersSuppliersExcept;
        private System.Windows.Forms.Button CustomersEmployeesExcept;
        private System.Windows.Forms.Button RegionShippersCross;
        private System.Windows.Forms.Button EmployeesCategoriesCross;
        private System.Windows.Forms.Button SuppliersProj;
        private System.Windows.Forms.Button CategoriesProj;
        private System.Windows.Forms.Button CustomersRen;
        private System.Windows.Forms.Button EmployeesCustomersUnion;
        private System.Windows.Forms.Button CustomersSuppliersUnion;
        private System.Windows.Forms.Button ProductsOrderDetailsExcept;
        private System.Windows.Forms.Button TerritoriesShippersCross;
        private System.Windows.Forms.Button EmployeesProj;
        private System.Windows.Forms.Button ProductsRen;
        private System.Windows.Forms.Button ShippersRen;
        private System.Windows.Forms.Button SuppliersOrdersUnion;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}

