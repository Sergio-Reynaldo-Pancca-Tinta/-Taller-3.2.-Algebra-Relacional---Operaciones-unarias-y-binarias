﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace taller_3._2_northwind
{
    public partial class Form1 : Form
    {
        // Corregido: Usamos el nombre real de tu mapeo de base de datos
        private NorthwindEntities context = new NorthwindEntities();

        public Form1()
        {
            InitializeComponent();
        }

        // ============================================================================
        // OPERACIONES UNARIAS
        // ============================================================================

        // --- SELECCIÓN (σ) ---
        private void button1_Click(object sender, EventArgs e)
        {
            dgvNorthwind.DataSource = context.Products.Where(p => p.CategoryID == 1).ToList();
        }

        private void CustomersSel_Click(object sender, EventArgs e)
        {
            var countries = new List<string> { "France", "Germany" };
            dgvNorthwind.DataSource = context.Customers.Where(c => countries.Contains(c.Country)).ToList();
        }

        private void OrdersSel_Click(object sender, EventArgs e)
        {
            dgvNorthwind.DataSource = context.Orders.Where(o => o.ShippedDate == null).ToList();
        }

        // --- PROYECCIÓN (π) ---
        private void SuppliersProj_Click(object sender, EventArgs e)
        {
            dgvNorthwind.DataSource = context.Suppliers
                .Select(s => new { s.CompanyName, s.Phone, s.ContactName }).ToList();
        }

        private void EmployeesProj_Click(object sender, EventArgs e)
        {
            dgvNorthwind.DataSource = context.Employees
                .Select(em => new { NombreCompleto = em.FirstName + " " + em.LastName, Cargo = em.Title }).ToList();
        }

        private void CategoriesProj_Click(object sender, EventArgs e)
        {
            dgvNorthwind.DataSource = context.Categories
                .Select(c => new { c.CategoryID, c.CategoryName }).ToList();
        }

        // --- RENOMBRAMIENTO (ρ) ---
        private void ProductsRen_Click(object sender, EventArgs e)
        {
            dgvNorthwind.DataSource = context.Products
                .Select(p => new { Identificador_Producto = p.ProductID, Nombre_Comercial = p.ProductName }).ToList();
        }

        private void CustomersRen_Click(object sender, EventArgs e)
        {
            dgvNorthwind.DataSource = context.Customers
                .Select(c => new { Codigo_Cliente = c.CustomerID, Ciudad_Sede = c.City, Pais_Origen = c.Country }).ToList();
        }

        private void ShippersRen_Click(object sender, EventArgs e)
        {
            dgvNorthwind.DataSource = context.Shippers
                .Select(s => new { Numero_Courier = s.ShipperID, Empresa_Transporte = s.CompanyName }).ToList();
        }

        // ============================================================================
        // OPERACIONES BINARIAS
        // ============================================================================

        // --- UNIÓN (∪) ---
        private void EmployeesCustomersUnion_Click(object sender, EventArgs e)
        {
            dgvNorthwind.DataSource = context.Employees.Select(em => new { Ciudad = em.City })
                .Union(context.Customers.Select(c => new { Ciudad = c.City })).ToList();
        }

        private void SuppliersOrdersUnion_Click(object sender, EventArgs e)
        {
            dgvNorthwind.DataSource = context.Suppliers.Select(s => new { Pais = s.Country })
                .Union(context.Orders.Select(o => new { Pais = o.ShipCountry })).ToList();
        }

        private void CustomersSuppliersUnion_Click(object sender, EventArgs e)
        {
            dgvNorthwind.DataSource = context.Customers.Select(c => new { Empresa = c.CompanyName })
                .Union(context.Suppliers.Select(s => new { Empresa = s.CompanyName })).ToList();
        }

        // --- DIFERENCIA (−) ---
        private void CustomersSuppliersExcept_Click(object sender, EventArgs e)
        {
            dgvNorthwind.DataSource = context.Customers.Select(c => new { Ciudad = c.City })
                .Except(context.Suppliers.Select(s => new { Ciudad = s.City })).ToList();
        }

        private void CustomersEmployeesExcept_Click(object sender, EventArgs e)
        {
            dgvNorthwind.DataSource = context.Customers.Select(c => new { Pais = c.Country })
                .Except(context.Employees.Select(em => new { Pais = em.Country })).ToList();
        }

        private void ProductsOrderDetailsExcept_Click(object sender, EventArgs e)
        {
            var todosLosIds = context.Products.Select(p => p.ProductID);
            var idsVendidos = context.Order_Details.Select(od => od.ProductID).Distinct();

            dgvNorthwind.DataSource = todosLosIds.Except(idsVendidos)
                .Select(id => new { ID_Producto_No_Vendido = id }).ToList();
        }

        // --- PRODUCTO CARTESIANO (×) ---
        private void RegionShippersCross_Click(object sender, EventArgs e)
        {
            dgvNorthwind.DataSource = context.Regions
                .SelectMany(r => context.Shippers, (r, s) => new { Region = r.RegionDescription.Trim(), Courier = s.CompanyName }).ToList();
        }

        private void EmployeesCategoriesCross_Click(object sender, EventArgs e)
        {
            dgvNorthwind.DataSource = context.Employees
                .SelectMany(em => context.Categories, (em, c) => new { ApellidoEmpleado = em.LastName, CategoriaProducto = c.CategoryName }).ToList();
        }

        private void TerritoriesShippersCross_Click(object sender, EventArgs e)
        {
            dgvNorthwind.DataSource = context.Territories.Take(5)
                .SelectMany(t => context.Shippers, (t, s) => new { Territorio = t.TerritoryDescription.Trim(), Courier = s.CompanyName }).ToList();
        }
    }
}